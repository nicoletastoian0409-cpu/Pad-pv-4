PAD - Proces verbal, varianta 0.2
ID instalare nou: ro.pad.procesverbal.nou (evita conflicte cu instalari vechi).
Arhiva contine folderul PAD_Android_Project pentru workflow-ul GitHub care il dezarhiveaza.
Nota: instalarea pe telefon nu a fost testata; in caz de eroare este necesar mesajul exact / codul adb.
